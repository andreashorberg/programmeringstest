#  Chuck Norris Joke App

## Kravspecifikation

### - Appen ska visa en lista med skämt hämtade från chucknorris.io

### - Skämten laddas in ett i taget genom att slumpas fram med en knapptryckning och sparas i lokal databas

### - Om ett skämt slumpas fram som redan finns i listan ska ett felmeddelande visas och skämtet sparas inte

### - Skämten i listan ska visa en text med de första 30 tecknen av skämtet följt av "..." samt datum då skämtet skapades i backend, listan ska sorteras enligt äldsta skämten överst

### - Listan ska visas i en UINavigationBar med titel "Chuck Norris Jokes" och en knapp uppe till höger för att slumpa fram skämt

### - När man trycker på ett skämt i listan ska man komma till en detaljvy som visar upp all metadata om ett skämt, detaljvyn ska följa MVVM-mönster.
